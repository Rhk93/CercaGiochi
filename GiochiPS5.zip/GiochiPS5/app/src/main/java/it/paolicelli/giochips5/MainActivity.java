package it.paolicelli.giochips5;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

// Copyright © Ignazio Paolicelli
public class MainActivity extends Activity {
    WebView w;
    FrameLayout root;
    View full;
    WebChromeClient.CustomViewCallback fullCb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        root = new FrameLayout(this);
        w = new WebView(this);
        root.addView(w, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        w.addJavascriptInterface(new Net(), "Net");
        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) { }
                return true;
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                if (full != null) { cb.onCustomViewHidden(); return; }
                full = v;
                fullCb = cb;
                root.addView(v, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                w.setVisibility(View.GONE);
            }

            @Override
            public void onHideCustomView() {
                if (full == null) return;
                root.removeView(full);
                full = null;
                w.setVisibility(View.VISIBLE);
                if (fullCb != null) fullCb.onCustomViewHidden();
                fullCb = null;
            }
        });
        setContentView(root);
        w.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (full != null) {
            if (fullCb != null) fullCb.onCustomViewHidden();
            root.removeView(full);
            full = null;
            fullCb = null;
            w.setVisibility(View.VISIBLE);
            return;
        }
        w.evaluateJavascript("window.indietro?indietro():false", v -> {
            if (!"true".equals(v)) finish();
        });
    }

    class Net {
        @JavascriptInterface
        public void get(final String url, final int id) {
            new Thread(() -> {
                String res = "";
                int code = -1;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(20000);
                    c.setRequestProperty("User-Agent", url.contains("wiki") ? "GiochiPS5/1.3 (Android app; personal use)" : "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36");
                    c.setRequestProperty("Accept-Language", "it-IT,it;q=0.9");
                    c.setInstanceFollowRedirects(true);
                    code = c.getResponseCode();
                    InputStream in = code < 400 ? c.getInputStream() : c.getErrorStream();
                    if (in != null) {
                        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
                        StringBuilder sb = new StringBuilder();
                        String l;
                        while ((l = r.readLine()) != null) sb.append(l).append('\n');
                        r.close();
                        res = sb.toString();
                    }
                } catch (Exception e) { code = -1; }
                final String js = "onNet(" + id + "," + code + "," + JSONObject.quote(res) + ")";
                runOnUiThread(() -> w.evaluateJavascript(js, null));
            }).start();
        }
    }
}
